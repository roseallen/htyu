package com.webTest.bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
	
	private String uri = "jdbc:mysql://localhost:3306/webtest?useUnicode=true&characterEncoding=utf8";
	private String name = "root";
	private String password= "YHTyht123";
	Connection con;
	Statement stmt;
	ResultSet rs;
	
	public void connect(){
		try {
				try {
					Class.forName("com.mysql.jdbc.Driver");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			con = DriverManager.getConnection(uri,name,password);
			stmt = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void connectClose(){
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ResultSet selectByUsername(String name){
		
		String sql = "SELECT * FROM userinfo WHERE username='"+name+"'";
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}
	
	public ResultSet selectByEmail(String email){
		
		String sql = "SELECT * FROM userinfo WHERE email='"+email+"'";
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}
	
	public int insertUser(String username,String password,String nickname,String email,String phone,String sex){
		int rs=0;
		String sql="insert into userinfo(username,password,nickname,email,phone,sex) values('"+username+"','"+password+
    			"','"+nickname+"','"+email+"','"+phone+"','"+sex+"')";
    	try {
			rs=stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return rs;
	}
}
