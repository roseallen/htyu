package com.example.tests;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class CsvTest {
	
	public ArrayList login_test() throws Exception{
		String FILE_PATH = "C:\\Users\\�����\\Desktop\\login.csv";
		File csv = new File( FILE_PATH); 
		DataInputStream in=new DataInputStream(new FileInputStream(csv));
		BufferedReader br = null;
		br = new BufferedReader(new InputStreamReader(in,"UTF-8"));
		String record;
		ArrayList<String> list=new ArrayList<>();
		while ((record = br.readLine()) != null) {
			 list.add(record);
		}
		
		return list;
	}
	
	public ArrayList register_test() throws Exception{
		String FILE_PATH = "C:\\Users\\�����\\Desktop\\register.csv";
		File csv = new File( FILE_PATH); 
		DataInputStream in=new DataInputStream(new FileInputStream(csv));
		BufferedReader br = null;
		br = new BufferedReader(new InputStreamReader(in,"UTF-8"));
		String record;
		ArrayList<String> list=new ArrayList<>();
		while ((record = br.readLine()) != null) {
			 list.add(record);
		}
		
		return list;
	}
	

}
