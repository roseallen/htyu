package com.webTest.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.webTest.service.infoCheck;

public class registerTest {
	infoCheck ic=new infoCheck();
	@Test
	public void usernameTest() {
		assertEquals(false, ic.usernameCheck("123ac"));
		assertEquals(false, ic.usernameCheck("12345acdes"));
		assertEquals(true, ic.usernameCheck("123asdw"));
		assertEquals(true, ic.usernameCheck("123asdw"));
	}
	@Test
	public void passwordTest() {
		assertEquals(false, ic.passwordCheck("As23"));
		assertEquals(false, ic.passwordCheck("As2345678912"));
		assertEquals(false, ic.passwordCheck("123456a"));
		assertEquals(false, ic.passwordCheck("123456A"));
		assertEquals(false, ic.passwordCheck("aaaaaAa"));
		assertEquals(true, ic.passwordCheck("12345aA"));
	}
	@Test
	public void cpasswordTest() {
		assertEquals(false, ic.cpasswordCheck("1234Aa", "Aa1234"));
		assertEquals(true, ic.cpasswordCheck("Aa1234", "Aa1234"));
	}
	
	@Test
	public void nicknameTest() {
		assertEquals(false, ic.nicknameCheck("123456789101"));
		assertEquals(true, ic.nicknameCheck("��123Aa"));
	}
	
	@Test
	public void emailTest() {
		assertEquals(false, ic.emailCheck("ad��12@"));
		assertEquals(false, ic.emailCheck("@ad��12"));
		assertEquals(true, ic.emailCheck("ad��12@ad��12"));
	}
	
	@Test
	public void phoneTest() {
		assertEquals(false, ic.phoneCheck("123a"));
		assertEquals(false, ic.phoneCheck("123456789101v"));
		assertEquals(true, ic.phoneCheck(""));
		assertEquals(true, ic.phoneCheck(null));
		assertEquals(true, ic.phoneCheck("12345678910"));
	}
}
