package com.webTest.service;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.webTest.bean.Database;
import com.webTest.bean.LoginUser;

public class LoginTest {
	
	public String loginTest(String name,String password) {
		
		LoginUser user = new LoginUser();
		int a=0;
		int flag=0;
		Database ds = new Database();
		ds.connect();
		ResultSet rs = ds.selectByUsername(name);
		try {
			rs.last();
			a = rs.getRow();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
			try {
				if (a>=1) {
					rs.beforeFirst();
						while (rs.next()) {
							user.setName(rs.getString(2));
							user.setPassword(rs.getString(3));
							if (password.equals(user.getPassword())) {
								flag = 1;
							}
						}
						if (flag == 0) {
							return ("�������");
						} else {
							return ("��¼�ɹ�");
						}
					
				} else {
					return ("�û������������");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return ("�û������������");
	}

}
