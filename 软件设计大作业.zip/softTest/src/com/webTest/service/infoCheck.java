package com.webTest.service;

public class infoCheck {
	public boolean usernameCheck(String username){
		if (username.matches("[0-9a-zA-Z]{6,9}")) {// �û�����ʽ��֤
			return true;
		}
		return false;
	}
	
	public boolean passwordCheck(String password){
		if (password.matches("(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])^[\\x00-\\xff]{7,11}")) {// �����ʽ��֤
			return true;
		}
		return false;
	}
	
	public boolean cpasswordCheck(String password,String cpassword){
		if(password.equals(cpassword)){
			return true;
		}
		return false;
	}
	
	public boolean nicknameCheck(String nickname){
		if (nickname.matches("[A-Za-z0-9\\u4e00-\\u9fa5]{0,10}")) {// �ǳƸ�ʽ��֤
			return true;
		}
		return false;
	}
	
	public boolean emailCheck(String email){
		if (email.matches("[A-Za-z0-9\\u4e00-\\u9fa5]+@[A-Za-z0-9\\u4e00-\\u9fa5]+([\\.A-Za-z0-9\\u4e00-\\u9fa5]+)+")) {// ���������ʽ��֤
			return true;
		}
		return false;
	}
	
	public boolean phoneCheck(String phone){
		if ((phone == null || phone.length() == 0) || phone.matches("[0-9]{11}")) {// �ֻ������ʽ��֤
			return true;
		}
		return false;
	}

}
