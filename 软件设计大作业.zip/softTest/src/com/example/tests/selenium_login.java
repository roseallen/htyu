package com.example.tests;

import com.thoughtworks.selenium.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.regex.Pattern;

public class selenium_login {
	private Selenium selenium;

	@Before
	public void setUp() throws Exception {
		selenium = new DefaultSelenium("localhost", 4444, "*firefox D:\\Program Files (x86)\\firefox.exe", "http://localhost:8080/");
		selenium.start();
	}

	@Test
	public void testUntitled() throws Exception {
		CsvTest ct = new CsvTest();
		ArrayList<String> list = new ArrayList<>();
		list = ct.login_test();
		for(int i=1;i<list.size();i++) {	
			selenium.open("/webTest/login.jsp");
			selenium.type("name=name", list.get(i).split(",")[0]);
			selenium.type("name=password", list.get(i).split(",")[1]);
			selenium.click("css=input[type=\"submit\"]");
		}
	}

	@After
	public void tearDown() throws Exception {
		selenium.stop();
	}
}
